class Car:
    current_speed = 0
    falling_speed = 0

    def __init__(self, title, model):
        self.title = title
        self.model = model

    def start_engine(self):
        print(f"{self.title} {self.model} engine start!")

    def gas(self):
        self.current_speed += 20
        print(self.current_speed)

    def stoped_engine(self):
        print(f"{self.title} {self.model} engine stoped!")

    def tormoz(self):
        self.current_speed -= 10
        print(self.current_speed)


    def get_car_info(Car):
        print(f""" 
              title:     {Car.title} 
              model:     {Car.model}
                       """)

audi = Car("Audi", "Lamar")
audi.start_engine()
audi.gas()
audi.tormoz()
audi.stoped_engine()
audi.get_car_info()
